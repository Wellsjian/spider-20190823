# 导入seleinum的webdriver接口
from selenium import webdriver
import time

# 创建浏览器对象
browser = webdriver.PhantomJS()
browser.get('http://www.baidu.com/')
html = browser.page_source

print(browser.page_source.find('aaaaaaaaaaaaaaa'))

# 获取快照
browser.save_screenshot('baidu.png')
time.sleep(5)

# 关闭浏览器
browser.quit()













