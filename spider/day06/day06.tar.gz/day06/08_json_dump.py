import json

# 示例1
item = {'name':'金毛狮王','card':'屠龙刀'}
with open('yt.json','a') as f:
  json.dump(item,f,ensure_ascii=False)

# 示例2
item_list = [
  {'name':'紫衫龙王','card':'123'},
  {'name':'青翼蝠王','card':'456'}
]
with open('ystlj.json','a') as f:
  json.dump(item_list,f,ensure_ascii=False)

















